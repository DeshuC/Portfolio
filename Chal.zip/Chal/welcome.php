<!DOCTYPE html>
<html>
<head>
  <title>Chalani Deshika</title>
  <style>
  </style>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<header>
    <nav>
      <ul>
        <li><a href="log.php">Log in</a></li>
        <li><a href="sign.php">Sign up</a></li>
        
      </ul>
    </nav>
  </header>
<section id="hero">
    <div class="container">
      <h1>CHALANI DESHIKA</h1>
      <h3>Web Designer</h3>
      <img src="chala.png" alt="My Photo">
    </div>
  </section>

  </body>
</html>